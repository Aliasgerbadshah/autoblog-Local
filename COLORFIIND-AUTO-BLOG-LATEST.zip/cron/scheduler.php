<?php
/**
 * AutoBlog SaaS - Scheduler Cron Job
 *
 * Set ONCE in Hostinger hPanel Cron Jobs to run every 5 minutes.
 * Command example:
 * wget -q -O - "https://apps.colorfiind.com/cron/scheduler.php?key=YOUR_SECRET"
 *
 * Processes scheduled_queue and publishes articles that are due.
 * Uses pre-generated HTML from campaign_items when available.
 * Uses Blogger API KEY (not OAuth) for publishing.
 */

// SAPI guard removed — Hostinger runs PHP as CGI/fPM, not CLI.
// Allow execution from both cron and web (for "Run Cron Now" button).
// Optionally restrict to POST requests from authenticated users when called via web.
$cli = (php_sapi_name() === 'cli');
if (!$cli) {
    require_once __DIR__ . '/../includes/database.php';
    require_once __DIR__ . '/../includes/auto_daily.php';
    $key = (string)($_GET['key'] ?? $_POST['key'] ?? '');
    $secret = function_exists('getAutoBlogCronSecret') ? getAutoBlogCronSecret() : '';
    $okKey = ($secret !== '' && hash_equals($secret, $key));
    if (!$okKey && ($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        http_response_code(403);
        die('Forbidden. Use the cron wget URL from Auto Blog, or POST from the dashboard.');
    }
}

require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/autoblog_engine.php';
require_once __DIR__ . '/../includes/anti_ai_sanitizer.php';
require_once __DIR__ . '/../includes/ai_provider.php';

// ---- Cron debugging helpers ----
// When the secret key is correct, print any PHP error as readable text instead of
// a blank HTTP 500, so Hostinger cron problems can be seen in the browser /
// the dashboard "Verify cron URLs" check.
if ($cli || !empty($okKey) || ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    @ini_set('display_errors', '1');
    error_reporting(E_ALL);
    set_exception_handler(function (Throwable $t) {
        if (!headers_sent()) { header('Content-Type: text/plain; charset=utf-8'); http_response_code(500); }
        echo '[AutoBlog Cron ERROR] ' . $t->getMessage() . ' @ ' . $t->getFile() . ':' . $t->getLine() . "\n";
        exit(1);
    });
    register_shutdown_function(function () {
        $e = error_get_last();
        if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
            if (!headers_sent()) header('Content-Type: text/plain; charset=utf-8');
            echo "\n[AutoBlog Cron FATAL] " . $e['message'] . ' @ ' . $e['file'] . ':' . $e['line'] . "\n";
        }
    });
}

$db = getDB();
$now = nowString();

$log = function($msg) {
    $line = "[" . date('Y-m-d H:i:s') . "][Scheduler] $msg\n";
    echo $line;
    error_log($line);
};

$log("Starting scheduler run at $now");

$stmt = $db->prepare("SELECT * FROM scheduled_queue WHERE status = 'Scheduled' AND scheduled_time <= ? ORDER BY scheduled_time ASC");
$stmt->execute([$now]);
$dueItems = $stmt->fetchAll();

$log("Found " . count($dueItems) . " items due for publishing");

foreach ($dueItems as $item) {
    $userId = $item['user_id'];
    $slotNumber = $item['slot_number'];
    $keyword = $item['keyword'];
    $category = $item['category'];
    $targetLink = $item['target_link'];
    $targetAnchor = $item['target_anchor'];
    $topicTitle = $item['topic_title'];
    $platform = $item['target_platform'] ?? 'local';

    $log("Processing item ID {$item['id']}: \"$topicTitle\" → $platform");

    try {
        // Check for pre-generated HTML
        $stmt = $db->prepare("SELECT ci.* FROM campaign_items ci JOIN campaigns c ON c.id = ci.campaign_id WHERE c.user_id = ? AND ci.title = ? AND ci.article_status = 'Final Article Approved' AND ci.html_path IS NOT NULL AND ci.html_path != '' ORDER BY ci.id DESC LIMIT 1");
        $stmt->execute([$userId, $topicTitle]);
        $existingItem = $stmt->fetch();

        if ($existingItem && !empty($existingItem['html_path'])) {
            $log("Found pre-generated HTML path: {$existingItem['html_path']}");

            // Use the app's own robust resolver (tries OUTPUT_DIR + sub_apps +
            // public_html + demo variants with correct slashes). The old manual
            // path list concatenated dirname(__DIR__) without a slash, producing
            // ".../sub_appspublished_posts/..." and always failing.
            $articleContent = function_exists('loadCampaignArticleContent') ? loadCampaignArticleContent($existingItem) : '';
            if ($articleContent !== '' && trim(strip_tags($articleContent)) !== '') {
                // loadCampaignArticleContent already extracts the <article> body.
                $art = ['title' => $existingItem['title'], 'slug' => slugify($existingItem['title']), 'content' => $articleContent, 'keyword' => $existingItem['primary_keyword'], 'category' => $category, 'featured_image' => ''];
                $log("Using pre-generated HTML for: $topicTitle");
            } else {
                $log("HTML file not found on disk for: $topicTitle — will rebuild with the correct title.");
                $existingItem = null;
            }
        }

        if (!$existingItem) {
            // Resolve THIS slot's saved Chat + Image accounts (per-slot model
            // choice is honored — e.g. gptimage on slot 1, klein on slot 2).
            $chatVault = [];
            $imageVault = [];
            if (!empty($slotNumber)) {
                try {
                    $ss2 = $db->prepare('SELECT chat_credential_id, image_credential_id FROM user_workspace_slots WHERE user_id = ? AND slot_number = ?');
                    $ss2->execute([$userId, $slotNumber]);
                    $slotCreds = $ss2->fetch() ?: [];
                    if (!empty($slotCreds['chat_credential_id'])) $chatVault = SecurityVault::getApiCredentialsById($userId, 'chat_api', $slotCreds['chat_credential_id']);
                    if (!empty($slotCreds['image_credential_id'])) $imageVault = SecurityVault::getApiCredentialsById($userId, 'image_api', $slotCreds['image_credential_id']);
                } catch (Throwable $e) {}
            }
            if (empty($chatVault)) $chatVault = SecurityVault::getApiCredentials($userId, 'chat_api');
            if (empty($imageVault)) $imageVault = SecurityVault::getApiCredentials($userId, 'image_api');

            if (empty($chatVault['api_key'])) throw new RuntimeException('Chat API credentials are required.');

            // ALWAYS keep the queued roadmap title. The old code called
            // ContentGenerator::generateHumanArticle1000Words() which returned a
            // generic "How to Master X" title — that renamed every post it rebuilt.
            $art = ['title' => $topicTitle, 'slug' => slugify($topicTitle), 'content' => '', 'keyword' => $keyword, 'category' => $category, 'featured_image' => ''];
            $prompt = "Write only researched HTML for an 1800 to 2200 word human-reviewed blog titled \"$topicTitle\" about $keyword. Use the approved internal link target $targetLink with natural anchor text $targetAnchor. Include correct headings, FAQ, schema only when supported, and relevant external citations. Do NOT insert any <img> tags, <figure> blocks, or image URLs — the publishing engine attaches one real topic image automatically.";
            $aiResult = AIProviderClient::chat($chatVault, $prompt);
            if (!$aiResult['success']) throw new RuntimeException($aiResult['error'] ?? 'Chat API failed');
            $art['content'] = AntiAiSanitizer::sanitizeText($aiResult['content']);
            $art['content'] = stripArticleImagesAndFigures($art['content']);

            // Topic-relevant thumbnail image (never a random stock monitor).
            $featuredUrl = topicPhotoUrlForTitle($art['title'], $keyword, 1);
            $imageVault = function_exists('blogSafeImageVault') ? blogSafeImageVault($imageVault) : $imageVault;
            $imageProvider = strtolower((string)($imageVault['provider'] ?? ''));
            $imageAllowed = ($imageProvider === 'pollinations') || (PHP_SAPI === 'cli' && in_array($imageProvider, ['openai', 'openrouter', 'custom'], true));
            if ($imageAllowed && !empty($imageVault['api_key'])) {
                // Chat-written detailed prompt (title + keyword + website theme),
                // same flow as the Image Prompt Tester, before calling the image API.
                $imgCtx = [
                    'domain_url' => (string)($targetLink !== '' ? $targetLink : ''),
                    'primary_keyword' => $keyword,
                    'h2s' => [],
                    'chat_vault' => $chatVault,
                ];
                $imgPrompt = shortTopicImagePrompt($art['title'], $keyword);
                if (function_exists('buildDetailedImagePrompt')) {
                    list($imgPrompt, $pSrc) = buildDetailedImagePrompt($art['title'], $keyword, $imgCtx);
                }
                $imageResult = AIProviderClient::image($imageVault, $imgPrompt);
                if (!empty($imageResult['success']) && !empty($imageResult['url'])) {
                    $featuredUrl = $imageResult['url'];
                }
            }
            $art['featured_image'] = $featuredUrl;
            $art['content'] = topicFigureHtml($art['title'], $keyword, $featuredUrl) . $art['content'];
        }

        if ($platform === 'blogger') {
            // Prefer the Blogger account chosen for this item's slot (per-slot isolation).
            $vault = [];
            if (!empty($slotNumber)) {
                try {
                    $db2 = getDB();
                    $ss = $db2->prepare('SELECT blogger_credential_id FROM user_workspace_slots WHERE user_id = ? AND slot_number = ?');
                    $ss->execute([$userId, $slotNumber]);
                    $bloggerCredId = (string)($ss->fetchColumn() ?: '');
                    if ($bloggerCredId !== '') $vault = SecurityVault::getApiCredentialsById($userId, 'blogger_api', $bloggerCredId);
                } catch (Throwable $e) {}
            }
            if (empty($vault)) $vault = SecurityVault::getApiCredentials($userId, 'blogger_api');
            $blogId = $vault['blogger_blog_id'] ?? '';
            $clientId = $vault['client_id'] ?? '';
            $clientSecret = $vault['client_secret'] ?? '';
            $refreshToken = $vault['refresh_token'] ?? '';
            $log("Publishing to Blogger - Blog ID: $blogId, OAuth: " . (empty($refreshToken) ? 'NONE' : 'configured'));
            
            if (empty($blogId)) {
                throw new RuntimeException('Blogger Blog ID is required in the vault.');
            }
            if (empty($refreshToken)) {
                throw new RuntimeException('Blogger OAuth Refresh Token is required in the vault for publishing.');
            }
            
            $result = Publisher::publishBlogger($userId, $blogId, $art['title'], $art['content'], $clientId, $clientSecret, $refreshToken);
            if (!$result['success']) throw new RuntimeException($result['error'] ?? 'Blogger publishing failed');
            $log("Blogger publish success: " . ($result['url'] ?? 'no URL returned'));
        } elseif ($platform === 'wordpress') {
            $vault = SecurityVault::getApiCredentials($userId, 'wordpress_api');
            $result = Publisher::publishWordpress($userId, $vault['wp_site_url'] ?? '', $vault['wp_username'] ?? '', $vault['wp_app_password'] ?? '', $art['title'], $art['content']);
            if (!$result['success']) throw new RuntimeException($result['error'] ?? 'WordPress publishing failed');
            $log("WordPress publish success");
        } elseif ($platform === 'website') {
            if (!function_exists('publishToWebsiteBlog')) {
                $idx = dirname(__DIR__) . '/index.php';
            }
            $pubFile = dirname(__DIR__) . '/blog/includes/publisher.php';
            $alt = dirname(__DIR__, 2) . '/blog/includes/publisher.php';
            if (file_exists($alt)) require_once $alt;
            elseif (file_exists($pubFile)) require_once $pubFile;
            else throw new RuntimeException('Website publisher not found. Move blog/ to public_html/blog/.');
            $wpub = new WebsitePublisher();
            $thumbUrl = '';
            if (preg_match('#<img[^>]+src=["\']([^"\']+)["\']#i', $art['content'], $mImg)) $thumbUrl = $mImg[1];
            $result = $wpub->publish([
                'title' => $art['title'],
                'slug' => slugify($art['title']),
                'content_html' => $art['content'],
                'category' => $category,
                'tags' => [$keyword],
                'thumbnail_url' => $thumbUrl,
                'author' => 'ColorFiind Team',
                'meta_description' => substr(strip_tags($art['content']), 0, 160),
                'meta_keywords' => $keyword,
            ]);
            if (empty($result['success'])) throw new RuntimeException($result['error'] ?? 'Website blog publishing failed');
            $log("Website blog publish success: " . ($result['url'] ?? ''));
        } else {
            Publisher::publishLocal($userId, $art['title'], $art['slug'] ?? slugify($art['title']), $art['content'], $category, $keyword, $art['featured_image'] ?? '');
            $log("Local publish success");
        }

        $stmt2 = $db->prepare("UPDATE scheduled_queue SET status = 'Published' WHERE id = ?");
        $stmt2->execute([$item['id']]);
        $log("Published: $topicTitle to $platform");

    } catch (Exception $exc) {
        $retries = intval($item['retry_count'] ?? 0) + 1;
        if ($retries < 8) {
            $stmt2 = $db->prepare("UPDATE scheduled_queue SET status = 'Scheduled', retry_count = ?, error_message = ? WHERE id = ?");
            $stmt2->execute([$retries, strval($exc), $item['id']]);
            $log("RETRY {$retries}/8 item {$item['id']}: " . $exc->getMessage());
        } else {
            $stmt2 = $db->prepare("UPDATE scheduled_queue SET status = 'Failed', retry_count = ?, error_message = ? WHERE id = ?");
            $stmt2->execute([$retries, strval($exc), $item['id']]);
            $log("ERROR item {$item['id']}: " . $exc->getMessage());
        }
    }
}

$log("Scheduler run complete. Processed " . count($dueItems) . " items");
